package ch.epfl.cs107.play.game.superpacman.area;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.AreaGraph;
import ch.epfl.cs107.play.game.superpacman.actor.Ghosts;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Window;

public abstract class SuperPacmanArea extends Area implements Logic {

	private SuperPacmanBehavior areaBehavior;
	private int diams;

	@Override

	// Mise à l'échelle de tous les niveaux à 15.f
	public final float getCameraScaleFactor() {
		return 15.f;
	}

	public abstract DiscreteCoordinates Spawn(); // methode qui nous donne le spawn du player a chaque aire

	public void desactiver(DiscreteCoordinates coords) { // desactiver les gates dans chaque air
		areaBehavior.getGraph().setSignal(coords, Logic.FALSE);

	}

	public void activer(DiscreteCoordinates coords) {// activer les gates
		areaBehavior.getGraph().setSignal(coords, Logic.TRUE);

	}

	@Override
	public boolean begin(Window window, FileSystem fileSystem) {

		// Test du bon lancement du jeu (if), si il return true alors le jeu est lancé

		if (super.begin(window, fileSystem)) {

			areaBehavior = new SuperPacmanBehavior(window, getTitle());

			setBehavior(areaBehavior);
			createArea();
			this.diams = 0;

			return true;
		}

		return false;
	}

	//

	public boolean isOn() {// si le nombre de diamants recueillie est egal au nombre de diamants total
							// alors le signal est on

		if (getDiams() == areaBehavior.getTotal()) {
			return true;
		}

		return false;
	}

	protected void createArea() {
		areaBehavior.registerActors(this);
	}

	public void setDiams(int ajouter) {// chaque fois que nous allons cueillir un diamant nous allons ajouter 1
		this.diams += ajouter;
	}

	public int getDiams() {// fonction pour savoir combien de diamants a ceuillie notre pacman
		return diams;

	}
	//RESETER LES FANTOMES
	public void resetGhosts() { // fonction qui reset tous les ghosts
		Ghosts[] liste = areaBehavior.getList();
		for (Ghosts ghosts : liste) {
			if (ghosts != null) {
				ghosts.resetGhost();
				ghosts.oublier();
			}
		}
	}

	public void setScared(boolean value) { // Fonction qui va s'utiliser lorsque le timer est egal 0 et que tous les
											// fantomes doivent devinir non effrayes
		Ghosts[] liste = areaBehavior.getList();
		for (Ghosts ghosts : liste) {
			if (ghosts != null) {
				ghosts.setAfraid(value);
			}
		}
	}

	public AreaGraph getGraph() { // fonction qui retourne le graph d'une aire
		return areaBehavior.getGraph();
	}

	public Ghosts[] liste_ghost() { // fonction qui retourne la liste de ghost
		return areaBehavior.getList();
	}

}
