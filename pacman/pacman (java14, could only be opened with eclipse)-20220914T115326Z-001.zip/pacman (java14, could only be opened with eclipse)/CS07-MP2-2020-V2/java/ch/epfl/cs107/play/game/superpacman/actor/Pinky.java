package ch.epfl.cs107.play.game.superpacman.actor;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.AreaGraph;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Path;
import ch.epfl.cs107.play.game.superpacman.area.SuperPacmanArea;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.RandomGenerator;
import ch.epfl.cs107.play.window.Canvas;

public class Pinky extends Ghosts {

	Orientation desireOrientation;

	private DiscreteCoordinates targetPos;
	private DiscreteCoordinates Spawn;
	Queue<Orientation> path;
	private int counter;
	private Path graphicPath;
	private int compteur;

	public Pinky(Area area, Orientation orientation, DiscreteCoordinates position) {
		super(area, orientation, position, "superpacman/ghost.pinky");
		this.path = new LinkedList<Orientation>();
		this.compteur = 0;

		this.graphicPath = new Path(this.getPosition(), new LinkedList<Orientation>());
		// TODO Auto-generated constructor stub
	}

	@Override
	public void draw(Canvas canvas) {
		// TODO Auto-generated method stub
		//this.graphicPath.draw(canvas);
		super.draw(canvas);
	}

	public void update(float deltaTime) {

		super.update(deltaTime);

	}

	private void path_normal() { // path si le fantome n'a pas peur mais il connait pas le player
		Random r = new Random();
		AreaGraph areaGraph = ((SuperPacmanArea) this.getOwnerArea()).getGraph();
		do {
			this.targetPos = new DiscreteCoordinates(r.nextInt(getOwnerArea().getWidth()),
					r.nextInt(getOwnerArea().getHeight()));
		} while (DiscreteCoordinates.distanceBetween(this.getspawnPos(), targetPos) > MAX_DISTANCE_WHEN_NOT_SCARED
				|| (areaGraph.shortestPath(getCurrentMainCellCoordinates(), targetPos) == null));
		path = ((SuperPacmanArea) getOwnerArea()).getGraph().shortestPath(getCurrentMainCellCoordinates(), targetPos);

	}

	private void path_chase() {// path si le fantome n'a pas peur et il connait le player
		Random r = new Random();
		AreaGraph areaGraph = ((SuperPacmanArea) this.getOwnerArea()).getGraph();
		this.targetPos = this.getPlayer().getCell();
		path = ((SuperPacmanArea) getOwnerArea()).getGraph().shortestPath(getCurrentMainCellCoordinates(), targetPos);
	}

	private void path_scared_dumb() {// path si le fantome a peur mais il ne connait pas la pos du player
		Random r = new Random();
		AreaGraph areaGraph = ((SuperPacmanArea) this.getOwnerArea()).getGraph();

		if (getAfraid() && this.path.size() == 0) {

			do {
				this.targetPos = new DiscreteCoordinates(r.nextInt(getOwnerArea().getWidth()),
						r.nextInt(getOwnerArea().getHeight()));
			} while ((areaGraph.shortestPath(getCurrentMainCellCoordinates(), targetPos) == null)); // si la coordonne
																									// est accesible
			path = ((SuperPacmanArea) getOwnerArea()).getGraph().shortestPath(getCurrentMainCellCoordinates(),
					targetPos);
//			if (this.path == null) {
//				this.targetPos = null;
//			}

		}
	}

	public void setTargetPosition() {
		Random r = new Random();
		AreaGraph areaGraph = ((SuperPacmanArea) this.getOwnerArea()).getGraph();
		int compteur = 0;
		if (getAfraid()) {
			 if (this.path == null) {
				this.targetPos = null;
			}

			 else if (this.path!=null && (this.path.size() == 0) && (!getChase())) {

				this.path_scared_dumb();
			}
		
			
			else if (this.getChase()) {

				do {
					this.targetPos = new DiscreteCoordinates(r.nextInt(getOwnerArea().getWidth()),
							r.nextInt(getOwnerArea().getHeight()));
					compteur += 1;

				} 
				while ((DiscreteCoordinates.distanceBetween(this.getPlayer().getCell(),targetPos) < MIN_AFRAID_DISTANCE)
						&& (compteur < MAX_RANDOM_ATTEMPT)
						|| (areaGraph.shortestPath(getCurrentMainCellCoordinates(), targetPos) == null));

				if (compteur > MAX_RANDOM_ATTEMPT) {
					this.targetPos = null;

				}
				else {
				path = ((SuperPacmanArea) getOwnerArea()).getGraph().shortestPath(getCurrentMainCellCoordinates(),
						targetPos);
				}
			}
		}
			else {
				if (getChase()) {
					 path_chase();
					}
//	            if(this.path==null) {
//	    			this.targetPos = new DiscreteCoordinates(r.nextInt(getOwnerArea().getWidth()),
//	    					r.nextInt(getOwnerArea().getHeight()));
					//
//	            }
				else if (this.path == null) {
					this.targetPos = null;
				}

				 else if (this.path.size() == 0 && this.path!=null) {

					this.path_normal();

				}

			}
		}

	

	

	@Override
	public Orientation getNextOrientation() {
		if (path != null && targetPos != null) {
		//	this.graphicPath = new Path(this.getPosition(), new LinkedList<Orientation>(path));
			return path.poll();
		} else {
			return Orientation.fromInt(RandomGenerator.getInstance().nextInt(4));
		}

	}

}