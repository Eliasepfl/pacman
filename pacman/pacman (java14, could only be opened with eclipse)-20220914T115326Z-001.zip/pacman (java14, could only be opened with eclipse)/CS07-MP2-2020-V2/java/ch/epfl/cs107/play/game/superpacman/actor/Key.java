package ch.epfl.cs107.play.game.superpacman.actor;

import java.util.Collections;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.superpacman.handler.SuperPacmanInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Canvas;

public class Key extends SuperpacmanCollection implements Logic {

	public boolean collection;
	private Sprite sprite;

	public Key(Area area, DiscreteCoordinates position) {
		super(area, Orientation.RIGHT, position,false);
		this.collection = false;
		this.sprite = new Sprite("Superpacman/key", 1.f, 1.f, this);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {
		((SuperPacmanInteractionVisitor) v).interactWith(this);
	}

	public void setCollect() {
		this.collection = true;

	}

	@Override
	public boolean isOn() {
		return collection;
	}

	@Override
	public boolean isOff() {
		// TODO Auto-generated method stub
		return !collection;
	}

	@Override
	public float getIntensity() {
		// TODO Auto-generated method stub
		return (collection) ? 1 : 0;
	}

	@Override
	public List<DiscreteCoordinates> getCurrentCells() {
		return Collections.singletonList(getCurrentMainCellCoordinates());
	}

	@Override
	public boolean takeCellSpace() {
		return false;
	}

	@Override
	public boolean isCellInteractable() {
		return true;
	}

	@Override
	public boolean isViewInteractable() {
		return true;
	}

	public void update(float deltaTime) {

		super.update(deltaTime);

	}

	public void collect() {
		super.collect();
		setCollect();

	}

	@Override
	public void draw(Canvas canvas) {

		if (sprite != null) {
			sprite.draw(canvas);
		}

	}
}