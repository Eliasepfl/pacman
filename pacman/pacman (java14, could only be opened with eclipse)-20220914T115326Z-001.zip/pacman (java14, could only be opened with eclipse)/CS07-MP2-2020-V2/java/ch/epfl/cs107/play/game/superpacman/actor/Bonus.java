package ch.epfl.cs107.play.game.superpacman.actor;

import java.util.Collections;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Animation;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.rpg.actor.RPGSprite;
import ch.epfl.cs107.play.game.superpacman.handler.SuperPacmanInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Canvas;;

public class Bonus extends SuperpacmanCollection {

    private Sprite[] sprites;
    private final static int ANIMATION_DURATION = 3;
    private Animation animations;

    public Bonus(Area area, DiscreteCoordinates position) {
        super(area, Orientation.DOWN, position,true);

        sprites = RPGSprite.extractSprites("Superpacman/coin", 4, 1, 1,
                 this , 16, 16);
        animations = new Animation(ANIMATION_DURATION,sprites,true);

        // TODO Auto-generated constructor stub
    }

    @Override
    public List<DiscreteCoordinates> getCurrentCells() {
        return Collections.singletonList(getCurrentMainCellCoordinates());
    }

    @Override
    public boolean takeCellSpace() {
        return false;
    }

    @Override
    public boolean isCellInteractable() {
        return true;
    }

    @Override
    public boolean isViewInteractable() {
        return true;
    }



    public void update(float deltaTime) {

    	animations.update(deltaTime);
        super.update(deltaTime);


    }
    public void collect() {
        super.collect();

    }
    @Override
    public void draw(Canvas canvas) {


        animations.draw(canvas);

    }
    @Override
    public void acceptInteraction(AreaInteractionVisitor v) {
        // TODO Auto-generated method stub
        ((SuperPacmanInteractionVisitor)v).interactWith(this);

    }


}