package ch.epfl.cs107.play.game.superpacman.area;

import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.rpg.actor.Door;
import ch.epfl.cs107.play.game.superpacman.actor.Gate;
import ch.epfl.cs107.play.game.superpacman.actor.Key;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;

public class Level0 extends SuperPacmanArea{
	public String getTitle() {
		return "superpacman/Level0";
	}
	public static DiscreteCoordinates PLAYER_SPAWN_POSITION0=new DiscreteCoordinates(10,1);

	protected void createArea() {
		
		// Appel de la super classe pour initialiser l'aire de jeu       
		super.createArea();
		
		//  Enregistrement des deux cases (portes) qui vont permettre d'accéder à au niveau 1 
		//  Elles ne sont cependant qu'accessibles après la prise de la clé
        
		registerActor(new Door("superpacman/Level1", Level1.PLAYER_SPAWN_POSITION1, Logic.TRUE, this,Orientation.UP,new DiscreteCoordinates(5,9),new DiscreteCoordinates(6,9)));
        
        // Initialisation de la clé aux coordonées (3,4)
        
        Key cle = new Key(this,new DiscreteCoordinates(3,4));
        
        
        // Enregistrement de la clé et de la porte bloquant la route du premier niveau
        
        registerActor(cle);
        registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(5,8),cle));
        registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(6,8),cle));
	}
	
	// Permet de changer le signal en Off
	
	public boolean isOff() {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public float getIntensity() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public DiscreteCoordinates Spawn() {
		// TODO Auto-generated method stub
		return PLAYER_SPAWN_POSITION0;
	}

}
