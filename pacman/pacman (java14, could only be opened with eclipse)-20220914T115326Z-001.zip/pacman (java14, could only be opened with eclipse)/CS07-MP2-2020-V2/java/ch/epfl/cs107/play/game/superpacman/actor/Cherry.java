package ch.epfl.cs107.play.game.superpacman.actor;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.superpacman.handler.SuperPacmanInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import java.util.Collections;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.actor.Sprite;

import ch.epfl.cs107.play.window.Canvas;

public class Cherry extends SuperpacmanCollection {

	private Sprite sprite;

	public Cherry(Area area, DiscreteCoordinates position) {
		super(area, Orientation.DOWN, position, 200);
		this.sprite = new Sprite("Superpacman/cherry", 1.f, 1.f, this);
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<DiscreteCoordinates> getCurrentCells() {
		return Collections.singletonList(getCurrentMainCellCoordinates());
	}

	@Override
	public boolean takeCellSpace() {
		return false;
	}

	@Override
	public boolean isCellInteractable() {
		return true;
	}

	@Override
	public boolean isViewInteractable() {
		return true;
	}

	public void update(float deltaTime) {

		super.update(deltaTime);

	}

	public void collect() {
		super.collect();

	}

	@Override
	public void draw(Canvas canvas) {

		if (sprite != null) {
			sprite.draw(canvas);
		}

	}

	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {
		// TODO Auto-generated method stub
		((SuperPacmanInteractionVisitor) v).interactWith(this);

	}

}
