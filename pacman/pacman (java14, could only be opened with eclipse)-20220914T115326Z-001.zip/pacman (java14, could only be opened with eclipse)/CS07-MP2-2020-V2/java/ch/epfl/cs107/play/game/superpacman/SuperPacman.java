package ch.epfl.cs107.play.game.superpacman;

import ch.epfl.cs107.play.game.actor.ImageGraphics;
import ch.epfl.cs107.play.game.actor.SoundAcoustics;
import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.io.ResourcePath;
import ch.epfl.cs107.play.game.rpg.RPG;
import ch.epfl.cs107.play.game.rpg.actor.Player;
import ch.epfl.cs107.play.game.superpacman.actor.SuperPacmanPlayer;
import ch.epfl.cs107.play.game.superpacman.area.Level0;
import ch.epfl.cs107.play.game.superpacman.area.Level1;
import ch.epfl.cs107.play.game.superpacman.area.Level2;
import ch.epfl.cs107.play.game.superpacman.area.SuperPacmanArea;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Audio;
import ch.epfl.cs107.play.window.Keyboard;
import ch.epfl.cs107.play.window.Window;

public class SuperPacman extends RPG {

    SuperPacmanPlayer player;

	
    protected void initPlayer(Player player) {
        super.initPlayer(player); //initialiser le player

    }

    private void createAreas() {
    	//ajouter le area
        addArea(new Level0());
        addArea(new Level1());
        addArea(new Level2());

    }

    protected Player getPlayer() {
        return super.getPlayer();
    }

    public boolean begin(Window window, FileSystem fileSystem) {
        if (super.begin(window, fileSystem)) {
            createAreas();

            Area area = setCurrentArea("superpacman/Level0", true);


            player = new SuperPacmanPlayer(area, Orientation.DOWN, new DiscreteCoordinates(10, 1));
            initPlayer(player);
            return true;
        }
        return false;
    }

    @Override
    public void update(float deltaTime) {
//ici nous allons effectuer le timer, initialiser dans superpacmanplayer,
 //si le timer est inferieur a 0 alors le fantome na plus peur
    	Keyboard key = getCurrentArea().getKeyboard();

        pauseJeu(key);
        
        SuperPacmanArea area = (SuperPacmanArea) setCurrentArea(this.getCurrentArea().getTitle(), false);
        if (!player.isVulnerable()) {
            if (player.getTime() > 0) {
                player.setTime(deltaTime);


            } else if (player.getTime() < 0) {
                player.setTime(player.getTime());
                player.setVulnerability(true);
                area.setScared(false);
               

            }
            

        
       
        }
        
        gameover(player.getHp()<=0,key);
        


        super.update(deltaTime);
    }

    @Override
    public void end() {
    }


    @Override
    public String getTitle() {

        return ("Super Pac-Man");
    }
    public void gameover(boolean dead,Keyboard key) {
        
        ImageGraphics pauseMenu = new ImageGraphics(ResourcePath.getSprite("superpacman/gameover"),getCurrentArea().getCameraScaleFactor(),getCurrentArea().getCameraScaleFactor(), null);
        pauseMenu.setAnchor(new Vector(player.getPosition().x-(getCurrentArea().getCameraScaleFactor()/2),player.getPosition().y-getCurrentArea().getCameraScaleFactor()/2));
        pauseMenu.setDepth(2000);
        if(dead) {
         pauseMenu.draw(getWindow());
         if (key.get(Keyboard.ENTER).isPressed()) {
        	 System.exit(0);

         }
         
        }
        


       
        


        
        
    }

    public void pauseJeu(Keyboard key) {
    
        ImageGraphics pauseMenu = new ImageGraphics(ResourcePath.getSprite("superpacman/menu"),getCurrentArea().getCameraScaleFactor(),getCurrentArea().getCameraScaleFactor(), null);
        pauseMenu.setAnchor(new Vector(player.getPosition().x-(getCurrentArea().getCameraScaleFactor()/2),player.getPosition().y-getCurrentArea().getCameraScaleFactor()/2));
        pauseMenu.setDepth(2000);
        if (key.get(Keyboard.TAB).isPressed()) {
            getCurrentArea().gamePaused();
        }


        if(getCurrentArea().getPaused()) {
            pauseMenu.draw(getWindow());

        }
    }


}
