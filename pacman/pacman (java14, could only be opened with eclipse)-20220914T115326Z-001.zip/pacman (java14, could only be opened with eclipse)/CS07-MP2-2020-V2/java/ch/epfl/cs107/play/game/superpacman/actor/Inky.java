package ch.epfl.cs107.play.game.superpacman.actor;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.AreaGraph;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Path;
import ch.epfl.cs107.play.game.superpacman.area.SuperPacmanArea;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.RandomGenerator;
import ch.epfl.cs107.play.window.Canvas;

public class Inky extends Ghosts {

	Orientation desireOrientation;

	private DiscreteCoordinates targetPos;
	private Queue<Orientation> path;
//	private Path graphicPath;

	public Inky(Area area, Orientation orientation, DiscreteCoordinates position) {
		super(area, orientation, position, "superpacman/ghost.inky");

		//this.graphicPath = new Path(this.getPosition(), new LinkedList<Orientation>());
		this.path = new LinkedList<Orientation>();

		// TODO Auto-generated constructor stub
	}

	@Override
	public void draw(Canvas canvas) {
		// TODO Auto-generated method stub
		//this.graphicPath.draw(canvas);
		super.draw(canvas);
	}

	public void update(float deltaTime) {

		super.update(deltaTime);

	}

	private void path_scared() {//path si le fantome a peur
		Random r = new Random();
		AreaGraph areaGraph = ((SuperPacmanArea) this.getOwnerArea()).getGraph();

		if (getAfraid() && this.path.size() == 0) {

			do {
				this.targetPos = new DiscreteCoordinates(r.nextInt(getOwnerArea().getWidth()),
						r.nextInt(getOwnerArea().getHeight()));
			} while (DiscreteCoordinates.distanceBetween(this.getspawnPos(), targetPos) > MAX_DISTANCE_WHEN_SCARED
					|| (areaGraph.shortestPath(getCurrentMainCellCoordinates(), targetPos) == null)); // si la coordonne
																										// est accesible
			path = ((SuperPacmanArea) getOwnerArea()).getGraph().shortestPath(getCurrentMainCellCoordinates(),
					targetPos);

		}
	}
	
	private void path_chase() {//path si le fantome n'a pas peur et il connait le player
		Random r = new Random();
		AreaGraph areaGraph = ((SuperPacmanArea) this.getOwnerArea()).getGraph();
		this.targetPos = this.getPlayer().getCell();
		path = ((SuperPacmanArea) getOwnerArea()).getGraph().shortestPath(getCurrentMainCellCoordinates(),
				targetPos);
	}
	
	private void path_normal() { //path si le fantome n'a pas peur mais il connait pas le player
		Random r = new Random();
		AreaGraph areaGraph = ((SuperPacmanArea) this.getOwnerArea()).getGraph();
		do {
			this.targetPos = new DiscreteCoordinates(r.nextInt(getOwnerArea().getWidth()),
					r.nextInt(getOwnerArea().getHeight()));
		} while (DiscreteCoordinates.distanceBetween(this.getspawnPos(), targetPos) > MAX_DISTANCE_WHEN_NOT_SCARED
				|| (areaGraph.shortestPath(getCurrentMainCellCoordinates(), targetPos) == null));
		path = ((SuperPacmanArea) getOwnerArea()).getGraph().shortestPath(getCurrentMainCellCoordinates(),
				targetPos);
		
	}

	public void setTargetPosition() {
	

		if (getAfraid() && this.path.size() == 0) {
			path_scared();
		}
		else if(!getAfraid()) {
			if (getChase()) {
			path_chase();

		} 	else if (this.path.size() == 0) {
			path_normal();
			
		}
		}

	}

	@Override
	public Orientation getNextOrientation() {

		if (path != null && targetPos != null) {
		//	this.graphicPath = new Path(this.getPosition(), new LinkedList<Orientation>(path));
			return path.poll();
		} else {
			return Orientation.fromInt(RandomGenerator.getInstance().nextInt(4));
		}

	}

}
