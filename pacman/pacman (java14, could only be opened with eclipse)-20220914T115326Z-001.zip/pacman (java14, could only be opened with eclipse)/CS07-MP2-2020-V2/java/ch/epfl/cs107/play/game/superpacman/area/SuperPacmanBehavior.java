package ch.epfl.cs107.play.game.superpacman.area;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.AreaBehavior;
import ch.epfl.cs107.play.game.areagame.AreaGraph;
import ch.epfl.cs107.play.game.areagame.actor.Interactable;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.superpacman.actor.Blinky;
import ch.epfl.cs107.play.game.superpacman.actor.Bonus;
import ch.epfl.cs107.play.game.superpacman.actor.Cherry;
import ch.epfl.cs107.play.game.superpacman.actor.Diamond;
import ch.epfl.cs107.play.game.superpacman.actor.Ghosts;
import ch.epfl.cs107.play.game.superpacman.actor.Inky;
import ch.epfl.cs107.play.game.superpacman.actor.Pinky;
import ch.epfl.cs107.play.game.superpacman.actor.Wall;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Window;

public class SuperPacmanBehavior extends AreaBehavior {
	public enum SuperPacmanCellType{
		//
		NONE(0), // never used as real content
		WALL ( -16777216), //black
		FREE_WITH_DIAMOND(-1), //white
		FREE_WITH_BLINKY (-65536), //red
		FREE_WITH_PINKY ( -157237), //pink
		FREE_WITH_INKY ( -16724737), //cyan
		FREE_WITH_CHERRY (-36752), //light red
		FREE_WITH_BONUS ( -16478723), //light blue
		FREE_EMPTY ( -6118750);

		final int type;
		
		
		SuperPacmanCellType(int type){
			this.type = type;
		}

		public static SuperPacmanCellType toType(int type){
			// Méthode analogue à Tuto2, pour assigner à chaque valeur des Cells de l'area de SuperPacman un type qui lui correspond
			// en fonction de sa valeur en int.
			
			for(SuperPacmanCellType ict : SuperPacmanCellType.values()){
				if(ict.type == type)
					return ict;
			}
			// When you add a new color, you can print the int value here before assign it to a type
			System.out.println(type);
			return NONE;
		}
	}
	

	/**
	 * Default Tuto2Behavior Constructor
	 * @param window (Window), not null
	 * @param name (String): Name of the Behavior, not null
	 */
	private int total;
	Ghosts [] liste=new Ghosts[10];
	static int index=0;
	private AreaGraph graph;

	public SuperPacmanBehavior(Window window, String name){
		super(window, name);
		this.total=0;
		this.graph=new AreaGraph();
		
		
		// Méthode qui parcourt chacune des cells de l'area entière pour lui associer une couleur en fonction de son type
		
		for(int t = 0; t < height; t++) {			
			for (int j = 0; j < width ; j++) {
				SuperPacmanCellType color = SuperPacmanCellType.toType(getRGB(height-1-t, j));
				setCell(j,t, new SuperPacmanCell(j,t,color));
				
			}
		}
		for(int y = 0; y < height; y++) {			
			for (int x = 0; x < width ; x++) {
		
				if(cellType(x,y)!=SuperPacmanCellType.WALL) {
					graph.addNode(new DiscreteCoordinates(x,y),
					x>0 && cellType(x-1,y) !=SuperPacmanCellType.WALL,
					y<height-1 && cellType(x,y+1) !=SuperPacmanCellType.WALL,
					x<width-1 && cellType(x+1,y) !=SuperPacmanCellType.WALL,
					y>0 && cellType(x,y-1) !=SuperPacmanCellType.WALL
					);
					
				}
			}
		}
	}
	public boolean Mur(int x,int y) {
		if(cellType(x,y)==SuperPacmanCellType.WALL) {
			return(true);
			
		}
		else {
			return false;
		}
	}
	private SuperPacmanCellType cellType(int x, int y) {
		return SuperPacmanCellType.toType(getRGB(height-1-y,x));
	}
	public AreaGraph getGraph() {
		return this.graph;
	}
	
	

	/**
	 * Cell adapted to the Tuto2 game
	 */
	public class SuperPacmanCell extends Cell {

		private final SuperPacmanCellType type;
		
		public  SuperPacmanCell(int x, int y, SuperPacmanCellType type){
			
			// Permet d'instancier la Cell fournie en fonction de ses coordonnées et son type
			 
			super(x, y);
			this.type = type;
		}
	
		@Override
		protected boolean canLeave(Interactable entity) {
		
			return true;
		}
		    
		@Override
		public boolean isCellInteractable() {
		
			return false;
		}
		
		public boolean wantsCellInteraction() {
		
			return true;
		}
		
		@Override
		
		public boolean isViewInteractable() {
		
			return false;
		
		}

		@Override
		public void acceptInteraction(AreaInteractionVisitor v) {}

		@Override
		protected boolean canEnter(Interactable entity) {	
			
			// Cette fonction permet à des cases de ne plus être traversable, les murs sont totalements 
			// traversables si l'on ne return pas "(!hasNonTraversableContent())"
			
			return (!hasNonTraversableContent());
		}
		
	}
	
	protected void registerActors(Area area) {
		
		// Ici, on parcourt à nouveau le cadrillage de l'Area,non plus pour associer ici à une cell en
		// question sa couleur mais son type prédéfini. Qui possédera des particularités, exemple un mur
		// n'est pas traversable. Ensuite on enregistre cette cet acteur dans Area à cet emplacement
		// grâce à la focntion registerActor(mode,x,y,area) qui l'a crée au préalable.
		
		for(int x=0;x<width;++x) {
			for (int y = 0; y < height ; y++) {
				SuperPacmanCellType mode = ( (SuperPacmanCell)getCell(x,y) ).type;
				registerActor(mode,x,y,area);
			}
		}
	}
	    // Ici, on vient tester avec un boolean si notre case Wall possède ou non (dans un rayon 3x3 autour de lui)
	    // la présence d'un autre Wall. Elle retourne true dans le cas de cette présence
	
	private boolean[][] getVoisin(int x,int y,SuperPacmanCellType type){
		
		// Tout d'abord on inite un tableau de taille 3x3 qui va représenter le rayon autour de notre case étudié,
		// on parcourt le tableau d'en haut à gauche à en bas à droite. On choisit abs=x-1 et ord=y+1 pour commencer 
		// notre rayon en haut à gauche pour le parcourir de façon linéaire.
		
		boolean[][] voisinage=new boolean[3][3];
		
		int abs=x-1;
		int ord=y+1;
		
		for(int line=0;line<3;line++) {
			for(int col=0;col<3;col++) {
				
				// Le try/catch nous permet ici de parcourir très facilement le tableau en testant les différents voisinages 
				// tout en éliminant les cas qui nous renverraient des OutOfBoundsException.(Dans le cas où notre case étudiée
				// se trouverait sur le bord de notre cadrillage). Et retourne false si une exception est rencontrée.
				// Ainsi un boolean est renvoyé quelque soit le cas.
				
				try{
					voisinage[line][col]=(((SuperPacmanCell)getCell(x= abs+line, y= ord-col)).type==type);
					
				} catch(Exception e) {
					voisinage[line][col]=false;
				}
			}
		}		
		
		return voisinage;
	}
	
	// Cette fonction nous retourne le nombre de diamants dans l'aire de jeu
	
	public int getTotal() {
		return total;
	}
	public Ghosts[] getList() {
		return liste;
	}

	// Le rôle de cette fonction est de créer l'acteur avec un type, et sa position dans l'aire de jeu.
	// On utilise un switch pour trier les cas entre les différents acteurs. Un cas spécial pour le mur
	// où l'on doit vérifier son voisinage.
	private void registerActor(SuperPacmanCellType type,int x,int y,Area area) {
		
		boolean[][] voisin=new boolean[3][3];
		DiscreteCoordinates pos=new DiscreteCoordinates(x,y);		
		
		switch(type) {
		
		case NONE:		
			break;
		
		case WALL:
			
			voisin=getVoisin(x,y,type);
			area.registerActor(new Wall(area,pos,voisin));
			
			break;
		
		case FREE_WITH_DIAMOND:
			
			// On recupère cette variable grâce à notre fonction getTotal()
			
			area.registerActor(new Diamond(area,pos));			
			total+=1;				
			
			break;
		
		case FREE_WITH_BLINKY:
			Ghosts fantome=new Blinky(area,Orientation.UP,pos);
			area.registerActor(fantome);
			liste[index]=fantome;
			index+=1;
			
			break;
		
		case FREE_WITH_PINKY:
			Ghosts fantomes1=new Pinky(area,Orientation.UP,pos);
			area.registerActor(fantomes1);
			liste[index]=fantomes1;
			index+=1;
			
			break;
		
		case FREE_WITH_INKY:
			Ghosts fantomes=new Inky(area,Orientation.UP,pos);
			area.registerActor(fantomes);
			liste[index]=fantomes;
			index+=1;
			break;
		
		case FREE_WITH_CHERRY:
			
			area.registerActor(new Cherry(area,pos));
			break;
		
		case FREE_WITH_BONUS:
			
			area.registerActor(new Bonus(area,pos));
			break;
		
		case FREE_EMPTY:
			
			break;
		}			
	}
}
