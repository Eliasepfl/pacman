
package ch.epfl.cs107.play.game.superpacman.actor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Animation;
import ch.epfl.cs107.play.game.areagame.actor.Interactable;
import ch.epfl.cs107.play.game.areagame.actor.Interactor;
import ch.epfl.cs107.play.game.areagame.actor.MovableAreaEntity;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.rpg.actor.RPGSprite;
import ch.epfl.cs107.play.game.superpacman.handler.SuperPacmanInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Canvas;

abstract public class Ghosts extends MovableAreaEntity implements Interactor {
	public final int GHOST_SCORE = 500;
	private boolean scared;

	private final static int ANIMATION_DURATION1 = 10;

	private Sprite[][] sprites;
	private Animation[] animations;
	@SuppressWarnings("unused")
	private Animation animationsimple;
	private Sprite[] sprites_scared;
	private Animation animations_scared;
	private DiscreteCoordinates pos;
	@SuppressWarnings("unused")
	private DiscreteCoordinates targetPos;;
	private SuperPacmanPlayer player;
	private GhostHandler handler;

	public final static int MAX_DISTANCE_WHEN_SCARED = 5;
	public final static int MIN_AFRAID_DISTANCE = 30;
	public final static int MAX_DISTANCE_WHEN_NOT_SCARED = 10;
	public final static int MAX_RANDOM_ATTEMPT = 200;

	private boolean chasing;

	public Ghosts(Area area, Orientation orientation, DiscreteCoordinates position, String key) {
		super(area, orientation, position);

		this.pos = position; // postion de spawn
		this.scared = false; // variable qui store si le fantome est scare
		// animations
		sprites_scared = RPGSprite.extractSprites("Superpacman/ghost.afraid", 4, 1, 1, this, 16, 16);

		animations_scared = new Animation(ANIMATION_DURATION1, sprites_scared, true);
		sprites = RPGSprite.extractSprites(key, 2, 1, 1, this, 16, 16,
				new Orientation[] { Orientation.UP, Orientation.RIGHT, Orientation.DOWN, Orientation.LEFT });

		animations = Animation.createAnimations(ANIMATION_DURATION1 / 4, sprites);

		handler = new GhostHandler();// handler

		this.targetPos = DiscreteCoordinates.ORIGIN;

		this.chasing = false;// variable qui nous dit si le fantome connait la pos du joueur
	}

	public boolean getChase() {
		return chasing;
	}

	// qui donne la position de spawn de fantome
	public DiscreteCoordinates getspawnPos() {

		return this.pos;

	}

	public void setAfraid(boolean value) {
		this.scared = value;

	}

	public boolean getAfraid() {
		return scared;
	}

	public void oublier() {// fonction qui va faire oublier le personnage
		this.chasing = false;
	}

	public abstract void setTargetPosition();

	@Override
	public List<DiscreteCoordinates> getFieldOfViewCells() {

		List<DiscreteCoordinates> tableau = new ArrayList<DiscreteCoordinates>();
		int x = (int) this.getPosition().x;
		int y = (int) this.getPosition().y;

		for (int line = -5; line < 5; line++) {
			for (int col = -5; col < 5; col++) {
				tableau.add(new DiscreteCoordinates(x + line, y + col));
			}
		}

		return tableau;

	}

	public void resetGhost() {
		getOwnerArea().leaveAreaCells(this, getEnteredCells());
		abortCurrentMove();
		resetMotion();
		setCurrentPosition(this.pos.toVector());
		getOwnerArea().enterAreaCells(this, getCurrentCells());
		oublier();// si on reset ils doivent pas chase le personnage
	}

	public SuperPacmanPlayer getPlayer() {
		return this.player;
	}

	private void souvenir(SuperPacmanPlayer player) {
		if (!this.getAfraid()) {
			this.chasing = true;
			this.player = player;
		}
	}

	public void update(float deltaTime) {

		if (getAfraid()) {
			if (!isDisplacementOccurs()) {
				setTargetPosition();
				animations_scared.reset();

				this.animationsimple = animations_scared;
				orientate(this.getNextOrientation());
				move(ANIMATION_DURATION1);

			}

			animations_scared.update(deltaTime);

			super.update(deltaTime);

		} else {

			if (!isDisplacementOccurs()) {
				setTargetPosition();

				animations[getOrientation().ordinal()].reset();
				this.animationsimple = animations[getOrientation().ordinal()];

				orientate(this.getNextOrientation());
				move(ANIMATION_DURATION1);

			}

			animations[getOrientation().ordinal()].update(deltaTime);

			super.update(deltaTime);

		}

	}

	// fonctions override
	@Override
	public List<DiscreteCoordinates> getCurrentCells() {
		// TODO Auto-generated method stub
		return Collections.singletonList(getCurrentMainCellCoordinates());

	}

	@Override
	public boolean takeCellSpace() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean wantsViewInteraction() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean wantsCellInteraction() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isCellInteractable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public void interactWith(Interactable other) {
		other.acceptInteraction(handler);

	}

	@Override
	public boolean isViewInteractable() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {
		((SuperPacmanInteractionVisitor) v).interactWith(this);

	}

	public int getPoints() {
		return GHOST_SCORE;

	}

	public abstract Orientation getNextOrientation();

	@Override
	public void draw(Canvas canvas) {
		if (getAfraid()) {
			animations_scared.draw(canvas);

		} else {
			animations[getOrientation().ordinal()].draw(canvas);
		}
	}

	private class GhostHandler implements SuperPacmanInteractionVisitor {

		public void interactWith(SuperPacmanPlayer player) {
			souvenir(player);// si on voit le player on doit sen souvenir

		}

	}

}
