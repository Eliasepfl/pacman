package ch.epfl.cs107.play.game.superpacman.actor;

import java.awt.Color;

import ch.epfl.cs107.play.game.actor.Graphics;
import ch.epfl.cs107.play.game.actor.ImageGraphics;
import ch.epfl.cs107.play.game.actor.TextGraphics;
import ch.epfl.cs107.play.game.areagame.io.ResourcePath;
import ch.epfl.cs107.play.math.Node;
import ch.epfl.cs107.play.math.RegionOfInterest;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Canvas;

public class SuperPacmanPlayerStatusGUI extends Node implements Graphics{
	
	final private float DEPTH = 10000000;
	
	/// Image dimension
    private float width, height;
    private SuperPacmanPlayer player;
    
    private ImageGraphics[] life;
    
    TextGraphics score;
    
    public SuperPacmanPlayerStatusGUI(SuperPacmanPlayer player){
    	setParent(player);
    	this.player = player;
    	this.life = new ImageGraphics[this.player.getMaxHp()];
    }

    @Override
    public void draw(Canvas canvas) {
		this.width = canvas.getScaledWidth();
		this.height = canvas.getScaledHeight();
		
		Vector anchor = canvas.getTransform().getOrigin().sub(new Vector(this.width/2,this.height/2));
		
		for(int i = 0;i<this.life.length;i++) {
			int color = 64;
			if((i+1) <= this.player.getHp()) {
				color = 0;
			}
						
			ImageGraphics life = new ImageGraphics
					( ResourcePath.getSprite ("superpacman/lifeDisplay"),
					1.f, 1.f, new RegionOfInterest (color /*color 0 yellow and 64 grey*/, 0, 64, 64) ,
					anchor.add(new Vector (((i*1.f)+0) /*offset*/, height - 1.375f )), 1, DEPTH );
			if(this.player.getHp()>0) {		
			life.draw(canvas);
			}
					
					this.life[i]=life;
			
		}
		
		this.score = new TextGraphics("SCORE: "+Integer.toString((int)this.player.getScore()), .9f, Color.CYAN);
		this.score.setAnchor(anchor.add(new Vector(6f, height - 1.25f)));
		
		this.score.draw(canvas);
			
	}

}
