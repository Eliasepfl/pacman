package ch.epfl.cs107.play.game.superpacman.handler;

import ch.epfl.cs107.play.game.rpg.actor.Door;
import ch.epfl.cs107.play.game.rpg.handler.RPGInteractionVisitor;
import ch.epfl.cs107.play.game.superpacman.actor.Ghosts;
import ch.epfl.cs107.play.game.superpacman.actor.Portal;
import ch.epfl.cs107.play.game.superpacman.actor.SuperPacmanPlayer;
import ch.epfl.cs107.play.game.superpacman.actor.SuperpacmanCollection;


public interface SuperPacmanInteractionVisitor extends RPGInteractionVisitor  {
    
	default public void interactWith(SuperPacmanPlayer player) {}
   
	default public void interactWith(Door porte) {}

    default  public void interactWith(SuperpacmanCollection objet) {}
    
    default  public void interactWith(Ghosts fantome) {}

    default  public void interactWith(Portal portal) {}
}