package ch.epfl.cs107.play.game.superpacman.area;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.superpacman.actor.Arrival;
import ch.epfl.cs107.play.game.superpacman.actor.Gate;
import ch.epfl.cs107.play.game.superpacman.actor.Key;
import ch.epfl.cs107.play.game.superpacman.actor.Portal;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.And;


public class Level2 extends SuperPacmanArea{
	
	//Initialisation de l'apparition après le passage de la porte du niveau 1.
	
	public static DiscreteCoordinates PLAYER_SPAWN_POSITION2=new DiscreteCoordinates(15,29);

	public String getTitle() {
		return "superpacman/Level2";
	}

	
	protected void createArea() {
        
		// Appel de la super classe pour initialiser l'aire de jeu
       
		super.createArea();
		
		// Initialisation des différentes clés
        
		Key cle1=(new Key(this,new DiscreteCoordinates(3,16)));
        Key cle2=(new Key(this,new DiscreteCoordinates(26,16)));
        Key cle3=(new Key(this,new DiscreteCoordinates(2,8)));
        Key cle4=(new Key(this,new DiscreteCoordinates(27,8)));
        And cle5 = new And(cle3,cle4);
        
        // Enregistrement des clés, préalablement initialisés, aux emplacements assignés.
        
        registerActor(cle1);
        registerActor(cle2);
        registerActor(cle3);
        registerActor(cle4);        
        
        // Enregistrement des différents gates, qui sont chacune associées à leur signal (de leur clé personnelle)
        
        registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(8,14),cle1));
        registerActor(new Gate(this,Orientation.DOWN,new DiscreteCoordinates(5,12),cle1));
        registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(8,10),cle1));
        registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(8,8),cle1));
        registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(21,14),cle2));
        registerActor(new Gate(this,Orientation.DOWN,new DiscreteCoordinates(24,12),cle2));
        registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(21,10),cle2));
        registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(21,8),cle2));
        registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(10,2),cle5));
        registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(19,2),cle5));
        registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(12,8),cle5));
        registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(17,8),cle5));
        registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(14,3),this));
        registerActor(new Gate(this,Orientation.RIGHT,new DiscreteCoordinates(15,3),this));
        
        
     // Enregistrement des portails et de leur arrivée correspondantes
        registerActor(new Portal(this,Orientation.UP, new DiscreteCoordinates(27,5), new DiscreteCoordinates(1,4)));
        registerActor(new Portal(this,Orientation.UP, new DiscreteCoordinates(1,26), new DiscreteCoordinates(27,28)));
        registerActor(new Arrival(this,Orientation.UP,new DiscreteCoordinates(27,28)));
        registerActor(new Arrival(this,Orientation.UP,new DiscreteCoordinates(1,4)));
	}

	@Override
	public boolean isOff() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public float getIntensity() {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public DiscreteCoordinates Spawn() {
		// TODO Auto-generated method stub
		return PLAYER_SPAWN_POSITION2;
	}
}
