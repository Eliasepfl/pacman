README:
POUR LANCER LE JEU il faut juste appuyer PLAY

Le jeu n'a pas beaucoup de complication.
On bouge le Pacman avec les fleches de notre clavier.
Si on veut faire pause on appui la touche TAB
Lorsque le vous perdez toutes vos vies, un ecran game over apparait, pour stoppez le jeu a ce moment la vous devez appuiyez la touche ENTER.
Le but est tres simple, passez les niveaux et ne pas se faire tuer(Pour passer d'un niveau à un autre il faut soit recuperer les cles(level0), soit ceuillir tous les diamants(level1), soit les deux(level2).


BONNE GAME