package ch.epfl.cs107.play.game.superpacman.actor;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.superpacman.areagame.actor.CollectableAreaEntity;
import ch.epfl.cs107.play.math.DiscreteCoordinates;

abstract public class SuperpacmanCollection extends CollectableAreaEntity {
    private int points;
    private boolean makeInvulnerable;
    
    public SuperpacmanCollection(Area area,Orientation orientation, DiscreteCoordinates position, boolean vulnerability) {
       //OBJET QUI TE FAIT INVULNERABLE
    	super(area, orientation, position);
        this.makeInvulnerable=vulnerability;
        // TODO Auto-generated constructor stub
    }

    public SuperpacmanCollection(Area area,Orientation orientation, DiscreteCoordinates position, int value) {
        //OBJET QUI TE DONNE DES POINTS
    	super(area, orientation, position);
        this.points=value;
        // TODO Auto-generated constructor stub
    }


    public int getPoints() {
        return this.points;

    }
    public void set_invulnerable(boolean value) {
    	this.makeInvulnerable=value;
    }
    public boolean makeInvulnerable() {
		return this.makeInvulnerable;
    	
    }
}