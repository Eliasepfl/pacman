package ch.epfl.cs107.play.game.superpacman.actor;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.AreaGraph;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Path;
import ch.epfl.cs107.play.game.superpacman.area.SuperPacmanArea;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.RandomGenerator;
import ch.epfl.cs107.play.window.Canvas;

public class Riky extends Ghosts{
    Orientation desireOrientation;

    private DiscreteCoordinates targetPos;
    private DiscreteCoordinates Spawn;
    private Queue<Orientation> path;
    private int counter;
    private Path graphicPath;

    public Riky(Area area, Orientation orientation, DiscreteCoordinates position) {
        super(area, orientation, position, "superpacman/ghost.Riky");

        this.graphicPath = new Path(this.getPosition(), new LinkedList<Orientation>());
        this.path = new LinkedList<Orientation>();
        

        // TODO Auto-generated constructor stub
    }

    @Override
    public void draw(Canvas canvas) {
        // TODO Auto-generated method stub
       // this.graphicPath.draw(canvas);
        super.draw(canvas);
    }

    public void update(float deltaTime) {

        super.update(deltaTime);

    }


    public List<DiscreteCoordinates> getFieldOfViewCells() {

        List<DiscreteCoordinates> tableau = new ArrayList<DiscreteCoordinates>();
        int x = (int) this.getPosition().x;
        int y = (int) this.getPosition().y;

        for (int line = -30; line < 30; line++) {
            for (int col = -30; col < 30; col++) {
                tableau.add(new DiscreteCoordinates(x+ line, y + col));
            }
        }

        return tableau;

    }

    private void path_chase() {// path si le fantome n'a pas peur et il connait le player
		Random r = new Random();
		AreaGraph areaGraph = ((SuperPacmanArea) this.getOwnerArea()).getGraph();
		this.targetPos = this.getPlayer().getCell();
		path = ((SuperPacmanArea) getOwnerArea()).getGraph().shortestPath(getCurrentMainCellCoordinates(), targetPos);
	}

    public void setTargetPosition() {
    	if(this.getChase()) {
    	path_chase();
    	}
    	else {
    		this.targetPos=null;
    	}


    }

    @Override
    public Orientation getNextOrientation() {

        if (path != null && targetPos != null) {
          //  this.graphicPath = new Path(this.getPosition(), new LinkedList<Orientation>(path));
            return path.poll();
        } else {
            return Orientation.fromInt(RandomGenerator.getInstance().nextInt(4));
        }

    }

}
