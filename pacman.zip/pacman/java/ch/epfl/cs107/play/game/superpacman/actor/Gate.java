package ch.epfl.cs107.play.game.superpacman.actor;

import java.util.Collections;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.AreaEntity;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.superpacman.area.SuperPacmanArea;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.RegionOfInterest;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Canvas;

public class Gate extends AreaEntity {
	private Logic signal;
	private Sprite sprite;
	private DiscreteCoordinates position;

	public Gate(Area area, Orientation orientation, DiscreteCoordinates position, Logic signal) {
		super(area, orientation, position);
		this.signal = signal;
		this.position = position;

		if (orientation == Orientation.DOWN || (orientation == Orientation.UP)) {
			this.sprite = new Sprite("superpacman/gate", 1f, 1f, this, new RegionOfInterest(0, 0, 64, 64));
		} else {
			this.sprite = new Sprite("superpacman/gate", 1f, 1f, this, new RegionOfInterest(0, 64, 64, 64));

		}

		// TODO Auto-generated constructor stub

	}

	@Override
	public List<DiscreteCoordinates> getCurrentCells() {
		// TODO Auto-generated method stub
		return Collections.singletonList(getCurrentMainCellCoordinates());
	}

	@Override
	public boolean takeCellSpace() {
		// TODO Auto-generated method stub
		if (signal.isOn()) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public boolean isCellInteractable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isViewInteractable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {
		// TODO Auto-generated method stub

	}

	public void update(float deltaTime) {

		if (signal.isOn()) {
			((SuperPacmanArea) getOwnerArea()).activer(position); // ACTIVE LE GATE POUR QUE PINKY PUISSE PASSER
		} else {
			((SuperPacmanArea) getOwnerArea()).desactiver(position); // DESACTIVE LE GATE POUR QUE PINKY NE PASSE PAS

		}

		super.update(deltaTime);
	}

	@Override
	public void draw(Canvas canvas) {

		if (!signal.isOn()) {
			sprite.draw(canvas);
		}

	}

}
