package ch.epfl.cs107.play.game.superpacman.actor;


import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.RandomGenerator;
import ch.epfl.cs107.play.window.Canvas;


public class Blinky extends Ghosts{
	
	


	public Blinky(Area area, Orientation orientation, DiscreteCoordinates position) {
		super(area, orientation, position,"superpacman/ghost.blinky");
		
		// TODO Auto-generated constructor stub
	}

	
	

	@Override
	public void draw(Canvas canvas) {
		// TODO Auto-generated method stub
		super.draw(canvas);
		
	}
	 public void update(float deltaTime) {
    		    

         super.update(deltaTime);

	        
        }


	
			

	@Override
	public Orientation getNextOrientation() {
		 int randomInt = RandomGenerator.getInstance().nextInt(4);

         return(Orientation.fromInt(randomInt)); //ORIENTATION RANDOM
	}




	@Override
	public void setTargetPosition() {
		// TODO Auto- method stub
	}
	

	 }