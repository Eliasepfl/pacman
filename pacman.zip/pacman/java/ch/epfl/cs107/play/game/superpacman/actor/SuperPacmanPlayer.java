package ch.epfl.cs107.play.game.superpacman.actor;

import java.util.Collections;
import java.util.List;

import ch.epfl.cs107.play.game.actor.SoundAcoustics;
import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Animation;
import ch.epfl.cs107.play.game.areagame.actor.Interactable;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.rpg.actor.Door;
import ch.epfl.cs107.play.game.rpg.actor.Player;
import ch.epfl.cs107.play.game.rpg.actor.RPGSprite;
import ch.epfl.cs107.play.game.superpacman.area.SuperPacmanArea;
import ch.epfl.cs107.play.game.superpacman.handler.SuperPacmanInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Audio;
import ch.epfl.cs107.play.window.Button;
import ch.epfl.cs107.play.window.Canvas;
import ch.epfl.cs107.play.window.Keyboard;

public class SuperPacmanPlayer extends Player implements Interactable {

	private final static int ANIMATION_DURATION = 6;

	// variables utiles pour l'animation
	private Sprite sprite;
	private Animation[] animations;
	private Animation animationsimple;
	private Sprite[][] sprites;

	// variables utiles pour linteraction
	private SuperPacmanPlayerHandler handler;
	Orientation desireOrientation;

	private float temps;
	private int collection;
	private boolean isDead;
	private boolean vulnerability;

	// pour imprimer le score et les points de vie
	SuperPacmanPlayerStatusGUI statusGUI;
	private int score = 0;
	final private int maxHp = 5;
	private int hp = 3;

	private SoundAcoustics sound_bonus;
	private SoundAcoustics sound_gameover;

	public SuperPacmanPlayer(Area area, Orientation orientation, DiscreteCoordinates coordinates) {
		super(area, orientation, coordinates);

		// l'animation
		sprite = new Sprite("superpacman/bonus", 1.f, 1.f, this);
		sprites = RPGSprite.extractSprites("superpacman/pacman", 4, 1, 1, this, 64, 64,
				new Orientation[] { Orientation.DOWN, Orientation.LEFT, Orientation.UP, Orientation.RIGHT });
		animations = Animation.createAnimations(ANIMATION_DURATION / 2, sprites);

		this.collection = 0; // VARIABLES QUI COLLECTE LE NOMBRE DE DIAMANRS
		this.vulnerability = true; // VARIABLES QUI STORE LA VULNERABILITE DU PLAYER
		handler = new SuperPacmanPlayerHandler(); // HANDLER

		desireOrientation = orientation;// VARIABLES QUI STOCKE L'ORIENTATION DU PLAYER

		this.resetMotion();
		this.statusGUI = new SuperPacmanPlayerStatusGUI(this);

		this.isDead = false; // VARIABLE QUI TE DIT SI LE PLAYER EST MORT OU PAS
		this.temps = 8 * 1E9f; // VARIABLES QUI DONNE LE TEMPS QUE PEUT ETRE LE FANTOME EFFRAYE

		this.sound_bonus = new SoundAcoustics("sounds/bonus.wav");
		this.sound_gameover = new SoundAcoustics("sounds/gameover.wav");
	}

	// FONCTIONS VULNERABILITE PLAYER
	public boolean isVulnerable() {// RETOURNE LA VULNERABILITE DU PLAYER
		return this.vulnerability;
	}

	public void setVulnerability(boolean value) { // DONNE LA VULNERABILITE AU PLAYER
		this.vulnerability = value;
	}

	// FONCTIONS VIE DU PLAYER
	public boolean isDead() {
		return this.isDead;
	}

	public void setDead(boolean value) {
		this.isDead = value;

		this.resetMotion();

	}

	// FONCTIONS QUI FONT BOUGER LE PLAYER
	public List<DiscreteCoordinates> getDesiredCells() {// FONCTION QUI TE DONNE LES PROCHAINES CELLULES SELON
														// L'ORIENTATION
		return Collections.singletonList(getCurrentMainCellCoordinates().jump(desireOrientation.toVector()));
	}

	private void changeOrien(Orientation orientation, Button b) {
		//
		if (b.isDown()) {
			desireOrientation = orientation; // IL STOCKE L'ORIENTATION VOULUE
		}
	}

	public void update(float deltaTime) {
		Keyboard keyboard = getOwnerArea().getKeyboard();

		changeOrien(Orientation.LEFT, keyboard.get(Keyboard.LEFT));
		changeOrien(Orientation.UP, keyboard.get(Keyboard.UP));
		changeOrien(Orientation.RIGHT, keyboard.get(Keyboard.RIGHT));
		changeOrien(Orientation.DOWN, keyboard.get(Keyboard.DOWN));
		if (!isDisplacementOccurs()) {
			animations[getOrientation().ordinal()].reset();

			if (getOwnerArea().canEnterAreaCells(this, getDesiredCells())) {// ANIMATION DU PLAYER SI IL EST ARRETE
				orientate(desireOrientation);
				move(ANIMATION_DURATION);
				animationsimple = animations[getOrientation().ordinal()];

			} else {

				move(ANIMATION_DURATION);
			}

		}

		animations[getOrientation().ordinal()].update(deltaTime);
		super.update(deltaTime);

	}
	// AUDIO

	@Override
	public void bip(Audio audio) {
		sound_bonus.bip(audio);
		this.sound_gameover.bip(audio);
	}

//FONCTIONS OVERRIDE
	@Override
	public boolean takeCellSpace() {
		return false;
	}

	@Override
	public boolean isCellInteractable() {
		return true;
	}

	@Override
	public boolean isViewInteractable() {
		return true;
	}

	@Override
	public List<DiscreteCoordinates> getCurrentCells() {
		return Collections.singletonList(getCurrentMainCellCoordinates());
	}

	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {
		((SuperPacmanInteractionVisitor) v).interactWith(this);
	}

	@Override
	public List<DiscreteCoordinates> getFieldOfViewCells() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean wantsCellInteraction() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean wantsViewInteraction() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void interactWith(Interactable other) {
		other.acceptInteraction(handler);
	}

	// FONCTIONS QUI DESSINE
	public void draw(Canvas canvas) {
		// TODO Auto-generated method stub

		animations[getOrientation().ordinal()].draw(canvas);
		this.statusGUI.draw(canvas);

	}

//FONCTIONS DU TIMER

	public float getTime() {
		return this.temps;
	}

	public void setTime(float deltatime) {
		this.temps -= deltatime;
	}

	// FONCTIONS POUR LE SCORE

	public int getScore() {
		return score;
	}

	// on ajoute le score
	public void addScore(int score) {
		this.score += score;
	}

	// FONCTIONS POUR LA VIE DU PERSONNAGE
	public int getHp() {

		return hp;
	}

	public void setHp(int value) {

		this.hp += value;
		if (hp <= 0) {
			this.sound_gameover.shouldBeStarted();
		} else if (hp == maxHp) {
			hp = hp;
		}

	}

	public int getMaxHp() {
		return maxHp;
	}

//FONCTION QUI RENVOIE LE NOMBRE DE DIAMANTS COLLECTES
	public int getCollection() {
		return collection;
	}

//FONCTION QUI RESET LE PLAYER SI IL EST MANGE
	public void resetPlayer() {
		SuperPacmanArea area = (SuperPacmanArea) getOwnerArea();
		getOwnerArea().leaveAreaCells(this, getEnteredCells());
		abortCurrentMove();
		resetMotion();
		setCurrentPosition(area.Spawn().toVector());// SPAWN methode implemente dans toutes les aires(level 0,1,2). permet de savoir la position de spawn
		getOwnerArea().enterAreaCells(this, getCurrentCells());

	}

	// FONCTION DONNE LES COORDONNES DU PERSONNAGE
	public DiscreteCoordinates getCell() {
		return getCurrentMainCellCoordinates();
	}

	// INTERACTIONS
	private class SuperPacmanPlayerHandler implements SuperPacmanInteractionVisitor {

		public void interactWith(Door porte) {// INTERACTION AVEC LA PORTE
			setIsPassingADoor(porte);
		}

		public void interactWith(SuperpacmanCollection objet) { // INTERACTION AVEC UN OBJET
			objet.collect(); // COLLECTER L'OBJET
			SuperPacmanArea area = (SuperPacmanArea) getOwnerArea();
			addScore(objet.getPoints());// AJOUTER LES POINTS
			if (objet.makeInvulnerable()) {
				temps = 8;// ON RESET LE TIMER A 8
				setVulnerability(false);// NOTRE PERSONNAGE DEVIENT INVINCIBLE
				area.setScared(true); // LES FANTOMES DEVIENNET EFFFRAYES
				sound_bonus.shouldBeStarted();
			}
		}

		public void interactWith(Ghosts ghost) {
			ghost.oublier(); // ON OUBLIE LE PERSONNAGE
			// il oublie le player

			if (isVulnerable()) { // SI NOTRE PERSONNAGE EST VULNERABLE
				if (ghost instanceof Riky) {
					addScore(ghost.getPoints());
					setHp(1);

					ghost.resetGhost();

				} else {
					setDead(true);// NOTRE PERSONNAGE MEURT
					setHp(-1);// ON REDUT LES HP

					resetPlayer(); // LE PERSONNAGE REVIENT A SA POSITION
					((SuperPacmanArea) getOwnerArea()).resetGhosts(); // ON RESET "LES" FANTOMES"
					ghost.oublier();
				}

			} else if (!isVulnerable()) { // SI IL EST INVINCIBLE
				addScore(ghost.getPoints());

				ghost.resetGhost();
				if (ghost instanceof Riky) {
					addScore(ghost.getPoints());
					setHp(1);

					ghost.resetGhost();
				} // ON RESET "lE" FANTOME

			}

		}

		public void interactWith(Portal portal) {
			SuperPacmanPlayer.super.setCurrentPosition(new Vector(portal.getArrival().x, portal.getArrival().y));

		}

	}
}
